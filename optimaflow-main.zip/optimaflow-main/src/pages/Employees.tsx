import React from "react";
import { Layout } from "@/components/Layout";
import Admin from "./Admin";

// We're renaming the route but keeping the functionality from Admin page
const Employees = () => {
  return <Admin />;
};

export default Employees;
