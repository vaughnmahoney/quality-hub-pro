export interface Group {
  id: string;
  name: string;
  description: string | null;
}