
import { ColumnFilterProps as OriginalColumnFilterProps } from "../types";

// Re-export using 'export type' for compatibility with isolatedModules
export type { OriginalColumnFilterProps as ColumnFilterProps };
